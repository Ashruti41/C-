//operator overloading
// +,-,*,/,=

#include<iostream>
using namespace std;

class Complex
{
  int real,img;

   public:
      Complex(){
       real=0;
       img = 0;
      }

     //parameter const
      Complex(int x,int y){
       real= x;
       img =y;
      }

     //display
      void Display(){
      cout<<"The value for real part: "<<real<<" and imginary part: "<<img<<endl<<endl;
      }

      //oprator overloading +
       Complex operator +(Complex ob){
          Complex temp;
          temp.real = real + ob.real;
          temp.img = img + ob.img;
          return temp;
        }
         Complex operator -(Complex ob){
          Complex temp;
          temp.real = real - ob.real;
          temp.img = img - ob.img;
          return temp;
        }
          Complex operator *(Complex ob){
          Complex temp;
          temp.real = real * ob.real-10;
          temp.img = img *ob.img-10;
          return temp;
        }

         Complex operator /(Complex ob){
          Complex temp;
          temp.real = real / ob.real+10;
          temp.img = img / ob.img+10;
          return temp;
        }

        Complex operator %(Complex ob){
         Complex temp;
         temp.real = real % ob.real;
         temp.img = img % ob.img;
         return temp;
        }

        Complex operator +=(Complex ob){
         Complex temp;
         temp.real = real += ob.real;
         temp.img = img += ob.img;
         return temp;
        }
       Complex operator ^(Complex ob){
          Complex temp;
          temp.real = real ^ ob.real+2;
          temp.img = img ^ ob.img-2;
          return temp;
        }
};

 int main()
{
     Complex c1(2,1),c2(5,10);
     Complex c3;
     c1.Display();
     c2.Display();
     c3.Display();
     c3 = c1.operator+(c2);
     c3.Display();
     int op;
    cout<<"The action stars here: "<<endl;
do{
    cout<<"1.sum"<<endl<<"2. Sub"<<endl<<"3.Mul"<<endl<<"4.Div"<<endl<<"5.%"<<endl<<"6.+="<<endl<<"7.-="<<endl<<"8.^"<<endl;
     cin>>op;
     switch(op){   
      case 1:
      c3 = c1 + c2;
      c3.Display();
      break;

      case 2:
      c3 = c1 - c2;
      c3.Display();
      break;
    
      case 3:
      c3 = c1 * c2;
      c3.Display();
      break;

      case 4:
      c3 = c2 / c1;
      c3.Display();
      break;

      case 5:
      c3 = c1 % c2;
      c3.Display();
      break;

      case 6:
      c3 = c1 += c2;
      c3.Display();
      break;
         
      case 7: 
      c3 = c1 -= c2;
      c3.Display();
      break;
    
      case 8:
      c3 = c1 ^ c2;
      c3.Display();
      break;
   } 
}while(op!=0);

return 0;
}
