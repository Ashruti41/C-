#include<iostream>
using namespace std;

class Complex
{
  int real,img;

   public:
      Complex(){
       real=0;
       img = 0;
      }

     //parameter const
      Complex(int x,int y){
       real= x;
       img =y;
      }

     //display
      void Display(){
      cout<<"The value for real part: "<<real<<" and imginary part: "<<img<<endl<<endl;
      }

      friend Complex operator +(Complex obj1,Complex obj2);
};

class Add{
     int a,b;
   
      public:
       Add(){
       a=0;
       b=0;
      }

      Add(int x,int y)
     {
       a = x;
       b = y;
      }

     void dis(){
      cout<<"The value of a : "<<a<<" and b : "<<b<<endl<<endl;
     }

    friend Add operator -(Add ob1,Add ob2);
};  
 

       Complex operator +(Complex obj1,Complex obj2){
          Complex temp;
          temp.real = obj1.real + obj2.real;
          temp.img = obj1.img + obj2.img;
          return temp;
        }

      Add operator -(Add ob1,Add ob2){
       Add temp;
       temp.a = ob1.a -ob2.a;
       temp.b = ob1.b -ob2.b;
       return temp;
   }
     int main(){
      
     Complex c1(1,1),c2(5,10);
     Complex c3;
     c1.Display();
     c2.Display();
     c3.Display();

     Add a1(2,3),a2(3,4);
     Add a3;
     a1.dis();
     a2.dis();
     a3.dis();

    cout<<"The action stars here: "<<endl;
      c3 = c1 - c2;
       c3.Display();

      a3 = a1 + a2;
      a3.dis();

return 0;
}   
