#include<iostream>
using namespace std;

class Complex
{
  int real,img;

   public:
      Complex(){
       real=0;
       img = 0;
      }

     //parameter const
      Complex(int x,int y){
       real= x;
       img =y;
      }

     //display
      void Display(){
      cout<<"The value for real part: "<<real<<" and imginary part: "<<img<<endl<<endl;
      }
      Complex operator +(Complex ob){
          Complex temp;
          temp.real = real + ob.real;
          temp.img = img + ob.img;
          return temp;
        }
       Complex operator -(Complex ob){
          Complex temp;
          temp.real = real - ob.real+5;
          temp.img = img - ob.img+4;
          return temp;
        }
       Complex operator *(Complex ob){
          Complex temp;
          temp.real = real * ob.real-10;
          temp.img = img *ob.img-10;
          return temp;
        }
      Complex operator /(Complex ob){
          Complex temp;
          temp.real = real / ob.real+10;
          temp.img = img / ob.img+10;
          return temp;
        }

       Complex operator %(Complex ob){
         Complex temp;
         temp.real = real % ob.real;
         temp.img = img % ob.img;
         return temp;
        }

        Complex operator +=(Complex ob){
         Complex temp;
         temp.real = real += ob.real;
         temp.img = img += ob.img;
         return temp;
        }
        Complex operator -=(Complex ob){
         Complex temp;
         temp.real = real += ob.real;
         temp.img = img += ob.img;
         return temp;
        }
         Complex operator ^(Complex ob){
          Complex temp;
          temp.real = real ^ ob.real+2;
          temp.img = img ^ ob.img-2;
          return temp;
        }  
      Complex operator *=(Complex ob){
          Complex temp;
          temp.real = real *= ob.real;
          temp.img = img *= ob.img;
          return temp;
        }
      
     
};

int main()
{
     Complex c1(2,1),c2(5,10);
     Complex c3;
     c1.Display();
     c2.Display();
     c3.Display();
     c3 = c1.operator+(c2);
     c3.Display();
   
     c3 = c1 - c2;
     c3.Display();

     c3 = c1 * c2;
     c3.Display();
 
     c3 = c1 / c2;
     c3.Display();

     c3 = c1 % c2;
     c3.Display();

     c3 = c1 += c2;
     c3.Display();

     c3 = c1 -= c2;
     c3.Display();

     c3 = c1 ^ c2;
     c3.Display();

     c3 = c1 *= c2;
     c3.Display();
  
return 0;
}
