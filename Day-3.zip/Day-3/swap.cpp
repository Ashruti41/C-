#include <iostream>
using namespace std;

void swap(int *A, int *B)//pass by pointers
{
    int temp;

    temp = *A;
    *A = *B;
    *B = temp;
}

int main()
{
    int a, b;

    cout << "Enter the numbers : " << endl;
    cin >> a;
    cin >> b;

    cout << "Before swap, a = " << a << ", b = " << b << endl;
    swap(&a, &b);
    cout << "After swap, a = " << a << ", b = " << b << endl;
}
