//function overloading

#include<iostream>
using namespace std;
int sum(int a){
 return a;
}

float sum(float a,float b){
 return a+b;
}
 
char sum(char a)
{
  return a;
}
char sum(char a,char b,char c)
{
 return a+b+c;
}
 

int main()
{
  
  cout<<"Sum= "<<sum(2)<<"\n";
  cout<<"Sum= "<<sum(2.0,3.5)<<"\n";
  cout<<"Sum= "<<sum('a')<<"\n";
  cout<<"Sum= "<<sum('A'+'B'+'D')<<"\n";

return 0;
}
