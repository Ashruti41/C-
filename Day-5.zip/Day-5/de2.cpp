#include<iostream>
using namespace std;

int cubevolume(int l=5, int w=6, int h=7)
{
  return l*w*h;
}

int main()
{
   cout<<"Cubevolume is: "<<cubevolume()<<endl;
   cout<<"Cubevolume is: "<<cubevolume(9)<<"\n";
   cout<<"Cubevolume is: "<<cubevolume(15,12)<<"\n";
   cout<<"Cubevolume is: "<<cubevolume(3,4,7)<<"\n";
return 0;
}
