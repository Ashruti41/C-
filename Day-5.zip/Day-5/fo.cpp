//function overloading

#include<iostream>
using namespace std;

int sum(int a){
 return a;
}

int sum(int a,int b){
 return a+b;
}

int sum(int a,int b,int c)
{
 return a+b+c;
}

int main()
{
  cout<<"Sum= "<<sum(2)<<"\n";
  cout<<"Sum= "<<sum(2+3)<<"\n";
  cout<<"Sum= "<<sum(2+3+4)<<"\n";

return 0;
}
