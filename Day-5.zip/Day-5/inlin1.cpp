//program for inline function (cube)

#include<iostream>
using namespace std;

inline int cube(int n)
{
   return n*n*n;
}

int main()
{
   cout<<"The cube is: "<<cube(3)<<"\n";
   return 0;
}

