//unaryoperator overloading with '-'
#include<iostream>
using namespace std;


class Space{
  int x,y,z;
    public:
     Space(){
      x=y=z=0;
     }

     Space(int a,int b,int c){
      x=a;
      y=b;
      z=c;
      }

     void Display(){
     cout<<"x="<<x<<",y="<<y<<",z="<<z;
    }

   void operator-();
 };

void Space::operator-()
{
  x = -x;
  y = -y;
  z = -z;
 }

  int main(){
   Space s1(5,4,3);
   s1.Display();
   -s1;
   cout<<"\n";
    s1.Display();
 return 0;
}
