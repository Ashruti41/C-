//new 
#include<iostream>
using namespace std;

int main(){
   int *pt = new int;
    *pt = 55;
 
    cout<<"value "<<*pt<<endl;
    cout<<"\nAddress"<<pt<<endl;
    cout<<"\nsize of int variable: "<<sizeof(*pt)<<endl;
    cout<<"\nsize of int pointer: "<<sizeof(pt)<<endl;
    cout<<"\nAddress of int pointer: "<<&pt<<endl;
 
  return 0;
}

