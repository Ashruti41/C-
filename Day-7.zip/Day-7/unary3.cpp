//unaryoperator overloading with '++'
#include<iostream>
using namespace std;


class Space{
  int x,y,z;
    public:
     Space(){
      x=y=z=0;
     }

     Space(int a,int b,int c){
      x=a;
      y=b;
      z=c;
      }

     void Display(){
     cout<<"x="<<x<<",y="<<y<<",z="<<z;
    }

   Space operator++();
    Space operator++(int);
 };

Space Space::operator++()
{
  cout<<"\nPost increment: ";
  Space temp;
  temp.x=x++;
  temp.y=y++;
  temp.z=z++;
  return temp;
 }
 Space Space::operator++(int)
{
  cout<<"\nPre-increment:";
  Space temp;
  temp.x=++x;
  temp.y=++y;
  temp.z=++z;
  return temp;
 }
 
  int main(){
   Space s1(2,3,4),s;
   s1.Display();
   s= ++s1;
   cout<<"\n";
   s.Display();
   s= s1++;
   cout<<"\n";
   s.Display();
 return 0;
}
