//unaryoperator overloading with '--'
#include<iostream>
using namespace std;


class Space{
  int x,y,z;
    public:
     Space(){
      x=y=z=0;
     }

     Space(int a,int b,int c){
      x=a;
      y=b;
      z=c;
      }

     void Display(){
     cout<<"x="<<x<<",y="<<y<<",z="<<z;
    }
   friend Space operator-(Space obj);
 };

 Space operator-(Space obj)
{
  Space temp;
  temp.x=-obj.x;
  temp.y=-obj.y;
  temp.z=-obj.z;
  return temp;
 }

  int main(){
   Space s1(5,4,3),s;
   s1.Display();
   s=-s1;
   cout<<"\n";
    s.Display();
 return 0;
}
